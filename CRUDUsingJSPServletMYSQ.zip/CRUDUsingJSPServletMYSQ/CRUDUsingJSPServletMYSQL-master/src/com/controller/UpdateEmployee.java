package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.service.EmployeeService;

@WebServlet("/update-employee")
public class UpdateEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmployeeService employeeService = new EmployeeService();
		HttpSession session = request.getSession();
		session.setAttribute("EmployeeById", employeeService.getEmployeeById(request.getParameter("id")));
		response.sendRedirect("index.jsp?update=true");

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EmployeeService employeeService = new EmployeeService();
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String department = request.getParameter("department");
		String salary=request.getParameter("salary");
			employeeService.updateEmployee(id,name, age,department,salary);
			response.sendRedirect("home");
	}

}
